<?php

/**
 * User: Alex Meng
 */
class FodelAPIException extends Exception
{
}