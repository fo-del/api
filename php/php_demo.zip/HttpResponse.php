<?php

/**
 * User: Alex Meng
 */
class HttpResponse
{

    public $body = '';

    public function __construct()
    {
    }
}